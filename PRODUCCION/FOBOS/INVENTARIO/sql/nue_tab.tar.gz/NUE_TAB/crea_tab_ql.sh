dbaccess $1 rept100.sql
dbaccess $1 rept101.sql
dbaccess $1 rept102.sql
dbaccess $1 rept103.sql
dbaccess $1 rept104.sql
dbaccess $1 rept105.sql
dbaccess $1 rept106.sql
dbaccess $1 rept107.sql
